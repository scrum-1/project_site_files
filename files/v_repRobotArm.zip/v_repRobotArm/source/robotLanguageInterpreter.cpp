// Copyright 2006-2015 Coppelia Robotics GmbH. All rights reserved. 
// marc@coppeliarobotics.com
// www.coppeliarobotics.com
// 
// -------------------------------------------------------------------
// THIS FILE IS DISTRIBUTED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
// WARRANTY. THE USER WILL USE IT AT HIS/HER OWN RISK. THE ORIGINAL
// AUTHORS AND COPPELIA ROBOTICS GMBH WILL NOT BE LIABLE FOR DATA LOSS,
// DAMAGES, LOSS OF PROFITS OR ANY OTHER KIND OF LOSS WHILE USING OR
// MISUSING THIS SOFTWARE.
// 
// You are free to use/modify/distribute this file for whatever purpose!
// -------------------------------------------------------------------
//
// This file was automatically created for V-REP release V3.2.1 on May 3rd 2015

/*****************************************************
 This file represents the robot language interpreter
 which is only provided as a very very simple
 example. Following commands/instructions are
 recognized (one command per line):
 ------------------------------------
 REM this is a comment section
 SETROTVEL x
 MOVE x1 x2 x3 x4 x5 x6
 WAIT x
 SETBIT x //x in [0,31]
 CLEARBIT x //x in [0,31]
 GRIP x //x in [0,1]
 IFBITGOTO x label //x in [0,31]
 IFNBITGOTO x label //x in [0,31]
 GOTO label
 label
 ------------------------------------
 SETROTVEL: sets the angular joint velocities for next movement to x (deg/sec)
 MOVE: moves the x robot joints to positions (x1 (deg), x2 (deg), x3 (deg), x4 (deg), ...) (at constant velocity v)
 WAIT: waits x miliseconds
 SETBIT: set the bit at position x in the robot output (1-32)
 CLEARBIT: clears the bit at position x in the robot output (1-32)
 GRIP: Opens (x=1) or closes (x=0) the grip
 IFBITGOTO: if bit x in the robot input (1-32) is set, then jump to label
 IFNBITGOTO: if bit x in the robot input (1-32) is NOT set, then jump to label
 GOTO: jumps to label. A label is any string different from REM, SETVEL, MOVE, WAIT or GOTO
**************************************************/

#include "robotLanguageInterpreter.h"
#include <boost/lexical_cast.hpp>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "v_repLib.h"

const float piValue=3.14159265f;
std::vector<SCompiledProgramLine> _compiledRobotLanguageProgram;

bool _extractOneLine(std::string& inputString,std::string& extractedLine)
{ // Extracts one line from a multi-line string
	extractedLine="";
	while (inputString.length()!=0)
	{
		char c=inputString[0];
		inputString.erase(inputString.begin());
		if ( (c==char(13))||(c==char(10)) )
		{
			if (c==char(10))
				break;
		}
		else
			extractedLine+=c;
	}
	return(extractedLine.length()!=0);
}

bool _extractOneWord(std::string& line,std::string& extractedWord)
{ // Extracts one word from a string (words are delimited by spaces)
	extractedWord="";
	while (line.length()!=0)
	{
		char c=line[0];
		line.erase(line.begin());
		if (c==' ')
		{
			if (extractedWord.length()!=0)
				return(extractedWord.length()!=0);
		}
		else
			extractedWord+=c;
	}
	return(extractedWord.length()!=0);
}

bool _getCommandFromWord(const std::string& word,int& command)
{ // returns the command index for a string command
	command=-1; // label
	if (word.compare("MOVE")==0)
		command=0;
	if (word.compare("WAIT")==0)
		command=1;
	if (word.compare("GOTO")==0)
		command=2;
	if (word.compare("SETROTVEL")==0)
		command=3;
	if (word.compare("REM")==0)
		command=4;
	if (word.compare("SETBIT")==0)
		command=5;
	if (word.compare("CLEARBIT")==0)
		command=6;
	if (word.compare("IFBITGOTO")==0)
		command=7;
	if (word.compare("IFNBITGOTO")==0)
		command=8;
	if (word.compare("GRIP")==0)
		command=9;
	return(command!=-1);
}

bool _getIntegerFromWord(const std::string& word,int& theInteger)
{ // returns the integer value corresponding to a string
	try
	{
		theInteger=boost::lexical_cast<int>(word);
		return(true);
	}
	catch (boost::bad_lexical_cast &)
	{
		return(false);
	}
	return(false);
}

bool _getFloatFromWord(const std::string& word,float& theFloat)
{ // returns the float value corresponding to a string
	try
	{
		theFloat=boost::lexical_cast<float>(word);
		return(true);
	}
	catch (boost::bad_lexical_cast &)
	{
		return(false);
	}
	return(false);
}

void _removeFrontAndBackSpaces(std::string& word)
{ // removes spaces at the front and at the back of a string
	while ( (word.length()!=0)&&(word[0]==' ') )
		word.erase(word.begin());
	while ( (word.length()!=0)&&(word[word.length()-1]==' ') )
		word.erase(word.begin()+word.length()-1);
}

std::string compileCode(const std::string& inputCode,float initialJointPosition[NUM_JOINTS],float minJointPosition[NUM_JOINTS],float maxJointPosition[NUM_JOINTS],float initialJointVelocityWhenMoving, float gripperPosition, float minGripperPosition, float maxGripperPosition, SMtbRobotState *robotState, int console)
{	// This function "compiles" the robot language code
	// A return value different from "" indicates a compilation error

	for (int i=0;i<NUM_JOINTS;i++)
	{
		robotState->currentJointPosition[i]=initialJointPosition[i];
		robotState->minJointPosition[i]=minJointPosition[i];
		robotState->maxJointPosition[i]=maxJointPosition[i];
	}
	robotState->jointVelocityWhenMoving=initialJointVelocityWhenMoving;
	robotState->gripperPosition=gripperPosition;
	robotState->closeGripperPosition=minGripperPosition;
	robotState->openGripperPosition=maxGripperPosition;
	robotState->currentProgramLine=0;
	robotState->lastProgramLine=-1;
	robotState->console=console;

	std::vector<std::string> labels;
	std::vector<int> labelLocations;
	_compiledRobotLanguageProgram.clear();
	std::string code(inputCode);
	int errorOnLineNumber=-1; // no error for now
	std::string codeLine;
	int currentCodeLineNb=0;
	while (_extractOneLine(code,codeLine))
	{ //  get one code line
		currentCodeLineNb++;
		_removeFrontAndBackSpaces(codeLine);
		if (codeLine.length()!=0)
		{
			std::string originalLine(codeLine);
			std::string codeWord;
			if (_extractOneWord(codeLine,codeWord))
			{ // get the first word in the code line
				int cmd;
				_getCommandFromWord(codeWord,cmd); // get the equivalent command index for the word
				if (cmd==-1)
				{ // we have a label here
					_removeFrontAndBackSpaces(codeLine);
					if (codeLine.length()==0)
					{ // the line is ok.
						labels.push_back(codeWord);
						labelLocations.push_back(int(_compiledRobotLanguageProgram.size()));
					}
					else
					{ // there shouldn't be more text on this line!
						errorOnLineNumber=currentCodeLineNb;
						break;
					}
				}
				if (cmd==0)
				{ // we have a MOVE here
					bool error=false;
					float p[NUM_JOINTS];
					for (int i=0;i<NUM_JOINTS;i++)
					{
					  if (!_extractOneWord(codeLine,codeWord))
					  {
					    error=true;
					    break;
					  }
					  if (!_getFloatFromWord(codeWord,p[i]))
					  {
					    error=true;
				 	    break;
					  }
					}
					if (error)
					{
					  errorOnLineNumber=currentCodeLineNb;
					  break;
					}
					if (!_extractOneWord(codeLine,codeWord))
					{
					  SCompiledProgramLine a;
					  a.command=cmd;
					  a.correspondingUncompiledCode=originalLine;
					  for (int i=0;i<NUM_JOINTS;i++)
					  {
						  p[i]*=(piValue/180.0f); // convert from deg to rad
						  if (p[i]>robotState->maxJointPosition[i])
							  p[i]=robotState->maxJointPosition[i];
						  if (p[i]<robotState->minJointPosition[i])
							  p[i]=robotState->minJointPosition[i];
						  a.floatParameter[i]=p[i];
					  }
					  _compiledRobotLanguageProgram.push_back(a);
					}
				}
				if (cmd==1)
				{ // we have a WAIT here
					bool error=true;
					if (_extractOneWord(codeLine,codeWord))
					{
						int t;
						if (_getIntegerFromWord(codeWord,t))
						{
							if (t>0)
							{
								if (!_extractOneWord(codeLine,codeWord))
								{
									error=false;
									SCompiledProgramLine a;
									a.command=cmd;
									a.correspondingUncompiledCode=originalLine;
									a.floatParameter[0]=float(t)/1000.0f; // convert from ms to s
									_compiledRobotLanguageProgram.push_back(a);
								}
							}
						}
					}
					if (error)
					{
						errorOnLineNumber=currentCodeLineNb;
						break;
					}
				}
				if (cmd==2)
				{ // we have a GOTO here
					bool error=true;
					if (_extractOneWord(codeLine,codeWord))
					{
						std::string label(codeWord);
						if (!_extractOneWord(codeLine,codeWord))
						{
							error=false;
							SCompiledProgramLine a;
							a.command=cmd;
							a.correspondingUncompiledCode=originalLine;
							a.tmpLabel=label;
							a.intParameter[0]=currentCodeLineNb; // the line number to jump to is set in the second compilation pass
							_compiledRobotLanguageProgram.push_back(a); 
						}
					}
					if (error)
					{
						errorOnLineNumber=currentCodeLineNb;
						break;
					}
				}
				if (cmd==3)
				{ // we have a SETROTVEL here
					bool error=true;
					if (_extractOneWord(codeLine,codeWord))
					{
						float v;
						if (_getFloatFromWord(codeWord,v))
						{
							if (v>0.0001f)
							{
								if (!_extractOneWord(codeLine,codeWord))
								{
									error=false;
									SCompiledProgramLine a;
									a.command=cmd;
									a.correspondingUncompiledCode=originalLine;
									a.floatParameter[0]=v*piValue/180.0f; // convert from deg/s to rad/s
									_compiledRobotLanguageProgram.push_back(a);
								}
							}
						}
					}
					if (error)
					{
						errorOnLineNumber=currentCodeLineNb;
						break;
					}
				}
				if (cmd==9)
				{ // we have a GRIP here
					bool error=true;
					if (_extractOneWord(codeLine,codeWord))
					{
						int g;
						if (_getIntegerFromWord(codeWord,g))
						{
							if (g==0 || g==1)
							{
								if (!_extractOneWord(codeLine,codeWord))
								{
									error=false;
									SCompiledProgramLine a;
									a.command=cmd;
									a.correspondingUncompiledCode=originalLine;
									if (g==0)
										a.floatParameter[0]=robotState->openGripperPosition;
									else
										a.floatParameter[0]=robotState->closeGripperPosition;
									_compiledRobotLanguageProgram.push_back(a);
								}
							}
						}
					}
					if (error)
					{
						errorOnLineNumber=currentCodeLineNb;
						break;
					}
				}
				if (cmd==4)
				{ // we have a comment here
				}
				if ((cmd==5)||(cmd==6))
				{ // we have a SETBIT or CLEARBIT here
					bool error=true;
					if (_extractOneWord(codeLine,codeWord))
					{
						int bitPos;
						if (_getIntegerFromWord(codeWord,bitPos))
						{
							if ((bitPos>0)&&(bitPos<33))
							{
								if (!_extractOneWord(codeLine,codeWord))
								{
									error=false;
									SCompiledProgramLine a;
									a.command=cmd;
									a.correspondingUncompiledCode=originalLine;
									a.intParameter[0]=bitPos; 
									_compiledRobotLanguageProgram.push_back(a);
								}
							}
						}
					}
					if (error)
					{
						errorOnLineNumber=currentCodeLineNb;
						break;
					}
				}
				if ((cmd==7)||(cmd==8))
				{ // we have a IFBITGOTO or IFNBITGOTO here
					bool error=true;
					if (_extractOneWord(codeLine,codeWord))
					{
						int bitPos;
						if (_getIntegerFromWord(codeWord,bitPos))
						{
							if ((bitPos>0)&&(bitPos<33))
							{
								if (_extractOneWord(codeLine,codeWord))
								{
									std::string label=codeWord;
									if (!_extractOneWord(codeLine,codeWord))
									{
										error=false;
										SCompiledProgramLine a;
										a.command=cmd;
										a.correspondingUncompiledCode=originalLine;
										a.tmpLabel=label;
										a.intParameter[0]=bitPos;
										a.intParameter[1]=currentCodeLineNb; // the line number to jumo to is set in the second compilation pass
										_compiledRobotLanguageProgram.push_back(a);
									}
								}
							}
						}
					}
					if (error)
					{
						errorOnLineNumber=currentCodeLineNb;
						break;
					}
				}
			}
		}
	}
	if (errorOnLineNumber!=-1)
	{ // we return an error message
		std::string retString("Error on line ");
		retString+=boost::lexical_cast<std::string>(currentCodeLineNb);
		retString+=".";
		return(retString);
	}
	else
	{ // we have a second pass where we need to set the line number where to jump to!
		for (unsigned int i=0;i<_compiledRobotLanguageProgram.size();i++)
		{
			if (_compiledRobotLanguageProgram[i].command==2)
			{ // this is a GOTO command.
				bool found=false;
				for (unsigned int j=0;j<labels.size();j++)
				{
					if (labels[j].compare(_compiledRobotLanguageProgram[i].tmpLabel)==0)
					{
						_compiledRobotLanguageProgram[i].intParameter[0]=labelLocations[j];
						found=true;
					}
				}
				if (!found)
				{
					std::string retString("Error on line ");
					retString+=boost::lexical_cast<std::string>(_compiledRobotLanguageProgram[i].intParameter[0]);
					retString+=".";
					return(retString);
				}
			}
			if ((_compiledRobotLanguageProgram[i].command==7)||(_compiledRobotLanguageProgram[i].command==8))
			{ // this is a IFBITGOTO or IFNBITGOTO command.
				bool found=false;
				for (unsigned int j=0;j<labels.size();j++)
				{
					if (labels[j].compare(_compiledRobotLanguageProgram[i].tmpLabel)==0)
					{
						_compiledRobotLanguageProgram[i].intParameter[1]=labelLocations[j];
						found=true;
					}
				}
				if (!found)
				{
					std::string retString("Error on line ");
					retString+=boost::lexical_cast<std::string>(_compiledRobotLanguageProgram[i].intParameter[1]);
					retString+=".";
					return(retString);
				}
			}
		}
		return(""); // no error!
	}
}

std::string runProgram(SMtbRobotState &robotState, unsigned char inputData[4],float deltaTime)
{	// This function runs the compiled robot language program for "deltaTime" seconds
	// return value "" means program ended!
	if (int(_compiledRobotLanguageProgram.size())<=robotState.currentProgramLine)
		return(""); // program end
	int cmd=_compiledRobotLanguageProgram[robotState.currentProgramLine].command; // get the current command
	int loopCnt=0;
	while (true)
	{
		if (robotState.console!=-1)
		{
			if (robotState.currentProgramLine!=robotState.lastProgramLine)
			{
			  simChar text[100];
			  sprintf(text,"%s\n",_compiledRobotLanguageProgram[robotState.currentProgramLine].correspondingUncompiledCode.c_str());
			  simAuxiliaryConsolePrint(robotState.console,text);
			  robotState.lastProgramLine=robotState.currentProgramLine;
			}
		}
		if (cmd==0)
		{ // MOVE 
			// We arrive at the same time at the desired positions for each joint
			float deltaTimeLeft;
			float biggestT=0.0f;
			for (int i=0;i<NUM_JOINTS;i++)
			{
				float dj=_compiledRobotLanguageProgram[robotState.currentProgramLine].floatParameter[i]-robotState.currentJointPosition[i];
				float vv=robotState.jointVelocityWhenMoving;
				/*if (i==2)
					vv=robotState.jointVelocityWhenMoving[0]; // This is a linear joint*/
				float t=fabs(dj)/vv;
				if (t>biggestT)
					biggestT=t;
			}
			for (int i=0;i<NUM_JOINTS;i++)
			{
				if (biggestT>deltaTime)
				{
					float dj=_compiledRobotLanguageProgram[robotState.currentProgramLine].floatParameter[i]-robotState.currentJointPosition[i];
					if (dj!=0.0f)
					{
						float vv=fabs(dj)/biggestT;
						robotState.currentJointPosition[i]+=vv*deltaTime*dj/fabs(dj);
					}
					deltaTimeLeft=0.0f;
				}
				else
				{
					robotState.currentJointPosition[i]=_compiledRobotLanguageProgram[robotState.currentProgramLine].floatParameter[i];
					deltaTimeLeft=deltaTime-biggestT;
				}
			}
			deltaTime=deltaTimeLeft;
			if (deltaTime>0.0f)
			{
				robotState.currentProgramLine++;
			}
			else
				break;
		}
		if (cmd==9)
		{ // GRIP
			// We arrive at the same time at the desired positions for each joint
			float deltaTimeLeft;
			float dj=_compiledRobotLanguageProgram[robotState.currentProgramLine].floatParameter[0]-robotState.gripperPosition;
			float vv=robotState.jointVelocityWhenMoving;
			float t=fabs(dj)/vv;
			//printf("dj=%f, vv=%f, t=%f\n",dj,vv,t);
			if (t>deltaTime)
			{
				if (dj!=0.0f)
					robotState.gripperPosition+=vv*deltaTime*dj/fabs(dj);
				deltaTimeLeft=0.0f;
			}
			else
			{
				robotState.gripperPosition=_compiledRobotLanguageProgram[robotState.currentProgramLine].floatParameter[0];
				deltaTimeLeft=deltaTime-t;
			}
			deltaTime=deltaTimeLeft;
			if (deltaTime>0.0f)
			{
				robotState.currentProgramLine++;
			}
			else
				break;
		}
		if (cmd==1)
		{ // WAIT
			float timeToWait=_compiledRobotLanguageProgram[robotState.currentProgramLine].floatParameter[0];
			timeToWait-=robotState.timeAlreadySpentAtCurrentProgramLine;
			if (timeToWait>deltaTime)
			{
				robotState.timeAlreadySpentAtCurrentProgramLine+=deltaTime;
				break;
			}
			else
			{
				deltaTime-=timeToWait;
				robotState.currentProgramLine++;
			}
		}
		if (cmd==2)
		{ // GOTO
			robotState.currentProgramLine=_compiledRobotLanguageProgram[robotState.currentProgramLine].intParameter[0]; // we jump
		}
		if (cmd==3)
		{ // SETROTVEL
			robotState.jointVelocityWhenMoving=_compiledRobotLanguageProgram[robotState.currentProgramLine].floatParameter[0];
			robotState.currentProgramLine++;
		}
		if (cmd==5)
		{ // SETBIT
			int pos=_compiledRobotLanguageProgram[robotState.currentProgramLine].intParameter[0];
			int bytePos=(pos-1)/8; // 0-3
			int bitPos=(pos-1)%8; //0-7
			robotState.outputData[bytePos]|=1<<bitPos;
			robotState.currentProgramLine++;
		}
		if (cmd==6)
		{ // CLEARBIT
			int pos=_compiledRobotLanguageProgram[robotState.currentProgramLine].intParameter[0];
			int bytePos=(pos-1)/8; // 0-3
			int bitPos=(pos-1)%8; //0-7
			robotState.outputData[bytePos]&=255-(1<<bitPos);
			robotState.currentProgramLine++;
		}
		if (cmd==7)
		{ // IFBITGOTO
			int pos=_compiledRobotLanguageProgram[robotState.currentProgramLine].intParameter[0];
			int bytePos=(pos-1)/8; // 0-3
			int bitPos=(pos-1)%8; //0-7
			if (inputData[bytePos]&(1<<bitPos))
			{ // we have to jump
				robotState.currentProgramLine=_compiledRobotLanguageProgram[robotState.currentProgramLine].intParameter[1]; // we jump
			}
			else
				robotState.currentProgramLine++;
		}
		if (cmd==8)
		{ // IFNBITGOTO
			int pos=_compiledRobotLanguageProgram[robotState.currentProgramLine].intParameter[0];
			int bytePos=(pos-1)/8; // 0-3
			int bitPos=(pos-1)%8; //0-7
			if ((inputData[bytePos]&(1<<bitPos))==0)
			{ // we have to jump
				robotState.currentProgramLine=_compiledRobotLanguageProgram[robotState.currentProgramLine].intParameter[1]; // we jump
			}
			else
				robotState.currentProgramLine++;
		}
		robotState.timeAlreadySpentAtCurrentProgramLine=0.0f;
		if (int(_compiledRobotLanguageProgram.size())<=robotState.currentProgramLine)
			return(""); // program end
		loopCnt++;
		if (loopCnt>1000)
			break; // We looped too often... maybe waiting for an input signal or simply infinite loop! we leave here
		cmd=_compiledRobotLanguageProgram[robotState.currentProgramLine].command;
	}
	return(_compiledRobotLanguageProgram[robotState.currentProgramLine].correspondingUncompiledCode); // return the string command that is being executed now
}

void getJointsGripperAndOutputData(SMtbRobotState &robotState, float jointPosition[NUM_JOINTS],float *gripperPosition,unsigned char outputData[4])
{
	for (int i=0;i<NUM_JOINTS;i++)
		jointPosition[i]=robotState.currentJointPosition[i];
	*gripperPosition=robotState.gripperPosition;
	for (int i=0;i<4;i++)
		outputData[i]=robotState.outputData[i];
}
